node ./src/index.js
echo "Press any key to continue"
read 1
